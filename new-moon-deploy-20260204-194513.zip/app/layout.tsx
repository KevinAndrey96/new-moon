import type { Metadata } from 'next'
import Script from 'next/script'
import WhatsAppButton from '../components/WhatsAppButton'

export const metadata: Metadata = {
  title: 'New Moon - Psicología en Evolución | Salud Mental Integral',
  description: 'New Moon Psicología en Evolución - Servicios de neuropsicología, psicología y sueroterapia. Evaluación, diagnóstico e intervención terapéutica para niños, adolescentes, adultos y empresas.',
  icons: {
    icon: '/images/logo.png',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const gaId = process.env.NEXT_PUBLIC_GA_ID || 'G-S7VK71NQKC'
  const v = process.env.NEXT_PUBLIC_ASSET_VERSION || '0'

  return (
    <html lang="es">
      <head>
        <meta httpEquiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
        <meta httpEquiv="Pragma" content="no-cache" />
        <meta httpEquiv="Expires" content="0" />
        <link rel="preload" href={`/css/style.css?v=${v}`} as="style" />
        <link href="https://fonts.googleapis.com/css?family=Work+Sans:100,200,300,400,500,600,700,800,900" rel="stylesheet" />
        <link href="https://fonts.googleapis.com/css?family=Fredericka+the+Great" rel="stylesheet" />
        <link rel="stylesheet" href={`/css/bootstrap.min.css?v=${v}`} />
        <link rel="stylesheet" href={`/css/open-iconic-bootstrap.min.css?v=${v}`} />
        <link rel="stylesheet" href={`/css/animate.css?v=${v}`} />
        <link rel="stylesheet" href={`/css/owl.carousel.min.css?v=${v}`} />
        <link rel="stylesheet" href={`/css/owl.theme.default.min.css?v=${v}`} />
        <link rel="stylesheet" href={`/css/magnific-popup.css?v=${v}`} />
        <link rel="stylesheet" href={`/css/aos.css?v=${v}`} />
        <link rel="stylesheet" href={`/css/ionicons.min.css?v=${v}`} />
        <link rel="stylesheet" href={`/css/flaticon.css?v=${v}`} />
        <link rel="stylesheet" href={`/css/icomoon.css?v=${v}`} />
        <link rel="stylesheet" href={`/css/style.css?v=${v}`} />
      </head>
      <body>
        <script
          dangerouslySetInnerHTML={{
            __html: `
              (function() {
                function hideLoader() {
                  var loader = document.getElementById('ftco-loader');
                  if (loader) {
                    loader.style.display = 'none';
                    loader.classList.remove('show');
                    loader.style.visibility = 'hidden';
                    loader.style.opacity = '0';
                  }
                }
                hideLoader();
                if (document.readyState === 'loading') {
                  document.addEventListener('DOMContentLoaded', hideLoader);
                }
                window.addEventListener('load', hideLoader);
                setTimeout(hideLoader, 100);
              })();
            `,
          }}
        />
        {children}
        <WhatsAppButton />
        
        {/* Google Analytics */}
        <Script
          src={`https://www.googletagmanager.com/gtag/js?id=${gaId}`}
          strategy="afterInteractive"
        />
        <Script id="google-analytics" strategy="afterInteractive">
          {`
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', '${gaId}');
          `}
        </Script>
        
        {/* Scripts (?v= para que cada deploy pida archivos nuevos y no use caché vieja) */}
        <Script src={`/js/jquery.min.js?v=${v}`} strategy="beforeInteractive" />
        <Script src={`/js/jquery-migrate-3.0.1.min.js?v=${v}`} strategy="afterInteractive" />
        <Script src={`/js/popper.min.js?v=${v}`} strategy="afterInteractive" />
        <Script src={`/js/bootstrap.min.js?v=${v}`} strategy="afterInteractive" />
        <Script src={`/js/jquery.easing.1.3.js?v=${v}`} strategy="afterInteractive" />
        <Script src={`/js/jquery.waypoints.min.js?v=${v}`} strategy="afterInteractive" />
        <Script src={`/js/jquery.stellar.min.js?v=${v}`} strategy="afterInteractive" />
        <Script src={`/js/owl.carousel.min.js?v=${v}`} strategy="afterInteractive" />
        <Script src={`/js/jquery.magnific-popup.min.js?v=${v}`} strategy="afterInteractive" />
        <Script src={`/js/aos.js?v=${v}`} strategy="afterInteractive" />
        <Script src={`/js/jquery.animateNumber.min.js?v=${v}`} strategy="afterInteractive" />
        <Script src={`/js/scrollax.min.js?v=${v}`} strategy="afterInteractive" />
        <Script src={`/js/main.js?v=${v}`} strategy="afterInteractive" />
      </body>
    </html>
  )
}

