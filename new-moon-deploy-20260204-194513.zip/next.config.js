/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'standalone',
  reactStrictMode: true,
  // Cada build tiene una versión distinta: las URLs de CSS/JS llevan ?v=... y el navegador no usa caché vieja
  env: {
    NEXT_PUBLIC_ASSET_VERSION: Date.now().toString(),
  },
  images: {
    unoptimized: true, // Disable image optimization for cPanel compatibility
  },
  assetPrefix: process.env.NODE_ENV === 'production' ? '' : '',
  // Todas las respuestas sin caché agresiva (evita que vistas no carguen hasta hacer Ctrl+Shift+R)
  async headers() {
    return [
      {
        source: '/:path*',
        headers: [
          {
            key: 'Cache-Control',
            value: 'no-cache, no-store, must-revalidate',
          },
        ],
      },
    ]
  },
}

module.exports = nextConfig

