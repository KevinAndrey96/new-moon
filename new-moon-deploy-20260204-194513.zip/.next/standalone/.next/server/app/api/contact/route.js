"use strict";(()=>{var e={};e.id=386,e.ids=[386],e.modules={517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},2081:e=>{e.exports=require("child_process")},6113:e=>{e.exports=require("crypto")},9523:e=>{e.exports=require("dns")},2361:e=>{e.exports=require("events")},7147:e=>{e.exports=require("fs")},3685:e=>{e.exports=require("http")},5687:e=>{e.exports=require("https")},1808:e=>{e.exports=require("net")},2037:e=>{e.exports=require("os")},1017:e=>{e.exports=require("path")},2781:e=>{e.exports=require("stream")},4404:e=>{e.exports=require("tls")},7310:e=>{e.exports=require("url")},3837:e=>{e.exports=require("util")},9796:e=>{e.exports=require("zlib")},301:(e,t,o)=>{o.r(t),o.d(t,{headerHooks:()=>m,originalPathname:()=>g,requestAsyncStorage:()=>c,routeModule:()=>l,serverHooks:()=>u,staticGenerationAsyncStorage:()=>p,staticGenerationBailout:()=>x});var r={};o.r(r),o.d(r,{GET:()=>GET,POST:()=>POST}),o(8976);var s=o(884),a=o(6132),n=o(5798),i=o(6709),d=o(6069);async function sendContactEmail(e){let t=function(){let e=process.env.SMTP_HOST||"",t=parseInt(process.env.SMTP_PORT||"587",10),o=process.env.SMTP_USER||"",r=process.env.SMTP_PASSWORD||"",s="true"===process.env.SMTP_SECURE||465===t;if(!e||!o||!r)throw Error("SMTP configuration is missing. Please set SMTP_HOST, SMTP_USER, and SMTP_PASSWORD environment variables.");return{smtpHost:e,smtpPort:t,smtpUser:o,smtpPassword:r,smtpSecure:s}}(),o=i.createTransport({host:t.smtpHost,port:t.smtpPort,secure:t.smtpSecure,auth:{user:t.smtpUser,pass:t.smtpPassword},tls:{rejectUnauthorized:!1}}),r=e.subject?`Formulario de Contacto: ${e.subject}`:"Nuevo Mensaje del Formulario de Contacto",s={from:`"${e.name}" <${t.smtpUser}>`,replyTo:e.email,to:d.dZ.email,subject:r,text:`
Nuevo Mensaje de Contacto
New Moon Psicolog\xeda en Evoluci\xf3n S.A.S.

Informaci\xf3n del Contacto:
- Nombre: ${e.name}
- Email: ${e.email}
${e.phone?`- Tel\xe9fono: ${e.phone}`:""}
${e.subject?`- Asunto: ${e.subject}`:""}

Mensaje:
${e.message}

---
Este mensaje fue enviado desde el formulario de contacto del sitio web.
Fecha: ${new Date().toLocaleString("es-CO",{timeZone:"America/Bogota"})}
  `.trim(),html:`
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Nuevo Mensaje de Contacto</title>
</head>
<body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
  <div style="background-color: #1e3a5f; color: white; padding: 20px; text-align: center; border-radius: 8px 8px 0 0;">
    <h1 style="margin: 0; font-size: 24px;">Nuevo Mensaje de Contacto</h1>
    <p style="margin: 10px 0 0 0; font-size: 14px;">New Moon Psicolog\xeda en Evoluci\xf3n S.A.S.</p>
  </div>
  
  <div style="background-color: #f8f9fa; padding: 30px; border-radius: 0 0 8px 8px; border: 1px solid #dee2e6; border-top: none;">
    <h2 style="color: #1e3a5f; margin-top: 0;">Informaci\xf3n del Contacto</h2>
    
    <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
      <tr>
        <td style="padding: 10px; background-color: white; border-bottom: 1px solid #dee2e6; font-weight: bold; width: 150px;">Nombre:</td>
        <td style="padding: 10px; background-color: white; border-bottom: 1px solid #dee2e6;">${e.name}</td>
      </tr>
      <tr>
        <td style="padding: 10px; background-color: white; border-bottom: 1px solid #dee2e6; font-weight: bold;">Email:</td>
        <td style="padding: 10px; background-color: white; border-bottom: 1px solid #dee2e6;">
          <a href="mailto:${e.email}" style="color: #1e3a5f; text-decoration: none;">${e.email}</a>
        </td>
      </tr>
      ${e.phone?`
      <tr>
        <td style="padding: 10px; background-color: white; border-bottom: 1px solid #dee2e6; font-weight: bold;">Tel\xe9fono:</td>
        <td style="padding: 10px; background-color: white; border-bottom: 1px solid #dee2e6;">
          <a href="tel:${e.phone}" style="color: #1e3a5f; text-decoration: none;">${e.phone}</a>
        </td>
      </tr>
      `:""}
      ${e.subject?`
      <tr>
        <td style="padding: 10px; background-color: white; border-bottom: 1px solid #dee2e6; font-weight: bold;">Asunto:</td>
        <td style="padding: 10px; background-color: white; border-bottom: 1px solid #dee2e6;">${e.subject}</td>
      </tr>
      `:""}
    </table>
    
    <h3 style="color: #1e3a5f; margin-top: 30px;">Mensaje:</h3>
    <div style="background-color: white; padding: 20px; border-left: 4px solid #ff6b35; border-radius: 4px; white-space: pre-wrap; line-height: 1.8;">
${e.message}
    </div>
    
    <div style="margin-top: 30px; padding-top: 20px; border-top: 2px solid #dee2e6; font-size: 12px; color: #666; text-align: center;">
      <p style="margin: 5px 0;">Este mensaje fue enviado desde el formulario de contacto del sitio web.</p>
      <p style="margin: 5px 0;">Fecha: ${new Date().toLocaleString("es-CO",{timeZone:"America/Bogota"})}</p>
    </div>
  </div>
</body>
</html>
  `.trim()};await o.sendMail(s)}async function POST(e){try{let t=await e.json(),{name:o,email:r,phone:s,subject:a,message:i}=t;if(!o||!r||!i)return n.Z.json({error:"name, email, and message are required"},{status:400});if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(r))return n.Z.json({error:"invalid email format"},{status:400});console.log("Contact form submission:",{name:o,email:r,phone:s,subject:a,timestamp:new Date().toISOString()});try{return await sendContactEmail({name:o,email:r,phone:s,subject:a,message:i}),console.log("Email sent successfully to info@nmpsicologiaenevolucion.com"),n.Z.json({success:!0,message:"message sent successfully"},{status:200})}catch(e){if(console.error("Error sending email:",e),e.message?.includes("SMTP configuration"))return n.Z.json({error:"email service not configured"},{status:500});return n.Z.json({error:"failed to send email"},{status:500})}}catch(e){return console.error("Error processing contact form:",e),n.Z.json({error:"internal server error"},{status:500})}}async function GET(){return n.Z.json({message:"Contact API endpoint. Use POST to submit forms."},{status:200})}let l=new s.AppRouteRouteModule({definition:{kind:a.x.APP_ROUTE,page:"/api/contact/route",pathname:"/api/contact",filename:"route",bundlePath:"app/api/contact/route"},resolvedPagePath:"/Users/kevinandrey/Documents/Moon/app/api/contact/route.ts",nextConfigOutput:"standalone",userland:r}),{requestAsyncStorage:c,staticGenerationAsyncStorage:p,serverHooks:u,headerHooks:m,staticGenerationBailout:x}=l,g="/api/contact/route"}};var t=require("../../../webpack-runtime.js");t.C(e);var __webpack_exec__=e=>t(t.s=e),o=t.X(0,[661,69],()=>__webpack_exec__(301));module.exports=o})();